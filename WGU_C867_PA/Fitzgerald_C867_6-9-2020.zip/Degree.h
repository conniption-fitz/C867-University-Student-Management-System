#ifndef DEGREE_H
#define DEGREE_H

using namespace std;

enum DegreeProgram {NO_DEGREE, SECURITY, NETWORK, SOFTWARE};
const string degreeProgramStrings[] = { "NO DEGREE", "SECURITY", "NETWORK", "SOFTWARE" };

#endif // !DEGREE_H

